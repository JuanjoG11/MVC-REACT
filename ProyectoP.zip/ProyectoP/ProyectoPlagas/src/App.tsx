import UserForm from "./views/UserForm";


function App() {
  return (
    <div>
      <UserForm />
    </div>
  );
}

export default App;
