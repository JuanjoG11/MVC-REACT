import { User } from "../models/User";

export class UserController {
    private users: User[] = [];

    registerUser(email: string, password: string, role: string): string {
        if (!this.isValidEmail(email)) {
            return "Correo electrónico inválido.";
        }
        if (!this.isValidPassword(password)) {
            return "La contraseña debe tener 8-15 caracteres, incluyendo mayúsculas, minúsculas, números y símbolos.";
        }

        const user = new User(email, password, role);
        this.users.push(user);
        return `¡Registro exitoso como ${role}!`;
    }

    private isValidEmail(email: string): boolean {
        const re = /^[\w-.]+@[\w-_]+(\.[a-zA-Z]{2,4}){1,2}$/;
        return re.test(email);
    }

    private isValidPassword(password: string): boolean {
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/;
        return passwordRegex.test(password);
    }
}
