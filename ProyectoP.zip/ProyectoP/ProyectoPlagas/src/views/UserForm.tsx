import { useState, useRef } from "react";
import { UserController } from "../Controllers/UserController";
import "../styles/styles.css";

const UserForm: React.FC = () => {
  const [message, setMessage] = useState<string>("");
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null);

  const emailRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);
  const roleRef = useRef<HTMLSelectElement>(null); // Nuevo selector de rol

  const controller = new UserController();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const email = emailRef.current?.value || "";
    const password = passwordRef.current?.value || "";
    const role = roleRef.current?.value || "Técnico"; // Por defecto, Técnico

    const resultMessage = controller.registerUser(email, password, role);
    setMessage(resultMessage);
    setIsSuccess(resultMessage.startsWith("¡Registro exitoso!"));

    if (isSuccess && emailRef.current && passwordRef.current) {
      emailRef.current.value = "";
      passwordRef.current.value = "";
    }
  };

  return (
    <div className="container">
      <h1>Registro de Usuario</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="role">Tipo de usuario:</label>
          <select id="role" ref={roleRef} required>
            <option value="Administrador">Administrador</option>
            <option value="Técnico">Técnico</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="email">Correo Electrónico:</label>
          <input type="email" id="email" ref={emailRef} required />
        </div>
        <div className="form-group">
          <label htmlFor="password">Contraseña:</label>
          <input type="password" id="password" ref={passwordRef} required />
        </div>
        <button type="submit">Registrarse</button>
      </form>
      {message && (
        <div id="message" style={{ color: isSuccess ? "green" : "red" }}>
          {message}
        </div>
      )}
    </div>
  );
};

export default UserForm;
